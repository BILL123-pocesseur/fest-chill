// supabase/functions/fedapay-payout/index.ts
//
// Appelée par festchill-wallet.html juste après fc_request_withdrawal()
// (qui a déjà vérifié le code PIN). Cette fonction envoie réellement
// l'argent via FedaPay (mobile money) vers l'organisateur.
//
// Variables d'environnement nécessaires : FEDAPAY_SECRET_KEY, FEDAPAY_ENV
// (identiques à fedapay-create-transaction).

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const FEDAPAY_ENV = Deno.env.get("FEDAPAY_ENV") || "sandbox";
const FEDAPAY_BASE = FEDAPAY_ENV === "live"
  ? "https://api.fedapay.com/v1"
  : "https://sandbox-api.fedapay.com/v1";
const FEDAPAY_SECRET_KEY = Deno.env.get("FEDAPAY_SECRET_KEY")!;

const supabaseAdmin = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    // Vérifie que l'appelant est bien connecté (le token de l'utilisateur
    // doit être transmis dans le header Authorization par le front).
    const authHeader = req.headers.get("Authorization");
    const supabaseUser = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader! } } },
    );
    const { data: { user } } = await supabaseUser.auth.getUser();
    if (!user) throw new Error("Non connecté");

    const { withdrawal_id } = await req.json();
    if (!withdrawal_id) throw new Error("withdrawal_id manquant");

    // Ne traite QUE les retraits appartenant à l'utilisateur connecté
    // (ceinture + bretelles, en plus de la RLS déjà en place).
    const { data: withdrawal } = await supabaseAdmin
      .from("withdrawals")
      .select("id, organizer_id, amount, operator, phone, status")
      .eq("id", withdrawal_id)
      .eq("organizer_id", user.id)
      .single();

    if (!withdrawal) throw new Error("Retrait introuvable");
    if (withdrawal.status !== "pending") throw new Error("Ce retrait a déjà été traité");

    // 1. Crée le dépôt (payout) chez FedaPay
    const modeMap: Record<string, string> = { mtn: "mtn_open", moov: "moov" };
    const createRes = await fetch(`${FEDAPAY_BASE}/payouts`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${FEDAPAY_SECRET_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        description: `Retrait Fest&Chill ${withdrawal.id}`,
        amount: withdrawal.amount,
        currency: { iso: "XOF" },
        mode: modeMap[withdrawal.operator] || "mtn_open",
        customer: { phone_number: { number: withdrawal.phone, country: "bj" } },
      }),
    });
    const createData = await createRes.json();
    if (!createRes.ok) {
      await supabaseAdmin.from("withdrawals").update({ status: "failed" }).eq("id", withdrawal_id);
      throw new Error(createData?.message || "Échec de création du dépôt FedaPay");
    }
    const payoutId = createData["v1/payout"]?.id || createData.id;

    // 2. Démarre réellement le dépôt
    const startRes = await fetch(`${FEDAPAY_BASE}/payouts/${payoutId}/start`, {
      method: "PUT",
      headers: { "Authorization": `Bearer ${FEDAPAY_SECRET_KEY}` },
    });
    const startData = await startRes.json();
    if (!startRes.ok) {
      await supabaseAdmin.from("withdrawals").update({ status: "failed" }).eq("id", withdrawal_id);
      throw new Error(startData?.message || "Échec du lancement du dépôt FedaPay");
    }

    // Le statut final (confirmé / échoué) arrive en réalité de façon
    // asynchrone chez FedaPay — pour rester simple ici, on marque
    // "confirmed" tout de suite. Pour être 100% exact, ajoute plus tard
    // un traitement de l'événement payout.transferred / payout.failed
    // dans fedapay-webhook, comme pour les transactions.
    await supabaseAdmin.from("withdrawals").update({ status: "confirmed" }).eq("id", withdrawal_id);

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
