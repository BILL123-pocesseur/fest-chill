// supabase/functions/fedapay-webhook/index.ts
//
// FedaPay appelle CETTE fonction (jamais le navigateur) quand un
// paiement est approuvé ou annulé. C'est la SEULE source de vérité
// pour dire "ce ticket a vraiment été payé".
//
// Configuration nécessaire :
//   1. Variables d'environnement (Supabase → Edge Functions → Secrets) :
//      FEDAPAY_WEBHOOK_SECRET   (visible sur FedaPay → Workbench → Webhooks
//                                → ton endpoint → "Click to reveal")
//   2. Sur le tableau de bord FedaPay → Workbench → Webhooks → Ajouter un
//      endpoint avec l'URL de cette fonction, une fois déployée :
//      https://TON-PROJET.supabase.co/functions/v1/fedapay-webhook
//      Écoute les événements : transaction.approved, transaction.canceled

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const FEDAPAY_WEBHOOK_SECRET = Deno.env.get("FEDAPAY_WEBHOOK_SECRET")!;

const supabaseAdmin = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

// Vérifie la signature HMAC-SHA256 envoyée par FedaPay dans
// l'en-tête X-FEDAPAY-SIGNATURE (format : "t=...,s=...")
async function verifySignature(rawBody: string, signatureHeader: string | null): Promise<boolean> {
  if (!signatureHeader) return false;
  const parts = Object.fromEntries(
    signatureHeader.split(",").map((p) => p.split("=") as [string, string]),
  );
  const timestamp = parts["t"];
  const signature = parts["s"];
  if (!timestamp || !signature) return false;

  const signedPayload = `${timestamp}.${rawBody}`;
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(FEDAPAY_WEBHOOK_SECRET),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sigBuffer = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(signedPayload));
  const computed = Array.from(new Uint8Array(sigBuffer)).map((b) => b.toString(16).padStart(2, "0")).join("");

  return computed === signature;
}

Deno.serve(async (req) => {
  const rawBody = await req.text();
  const signatureHeader = req.headers.get("x-fedapay-signature");

  const isValid = await verifySignature(rawBody, signatureHeader);
  if (!isValid) {
    return new Response("Signature invalide", { status: 401 });
  }

  const event = JSON.parse(rawBody);
  const eventName = event.name || event.type;
  const transaction = event.entity || event.data;
  const fedapayTransactionId = String(transaction?.id || "");

  if (!fedapayTransactionId) {
    return new Response("ok", { status: 200 });
  }

  // Retrouve la commande liée à cette transaction FedaPay
  const { data: order } = await supabaseAdmin
    .from("orders")
    .select("id, payment_status")
    .eq("fedapay_transaction_id", fedapayTransactionId)
    .single();

  if (!order) {
    return new Response("ok", { status: 200 }); // pas notre commande, on ignore
  }

  if (eventName === "transaction.approved" && order.payment_status === "pending") {
    await supabaseAdmin.rpc("fc_fedapay_confirm_order", {
      p_order_id: order.id,
      p_fedapay_transaction_id: fedapayTransactionId,
    });
  } else if (
    (eventName === "transaction.canceled" || eventName === "transaction.declined") &&
    order.payment_status === "pending"
  ) {
    await supabaseAdmin.rpc("fc_fedapay_reject_order", { p_order_id: order.id });
  }

  return new Response("ok", { status: 200 });
});
