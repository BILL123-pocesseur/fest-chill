// supabase/functions/fedapay-create-transaction/index.ts
//
// Appelée par festchill-buy-ticket.html juste après purchase_ticket()
// (qui réserve déjà la commande en statut "pending").
// Crée la transaction côté FedaPay (avec la clé SECRÈTE, jamais exposée
// au navigateur) et renvoie l'URL de paiement vers laquelle rediriger
// l'acheteur.
//
// Variables d'environnement à configurer (Supabase → Edge Functions →
// Secrets) :
//   FEDAPAY_SECRET_KEY   la clé secrète (test ou live) de ton compte FedaPay
//   FEDAPAY_ENV           "sandbox" ou "live"
// SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY sont fournies automatiquement.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const FEDAPAY_ENV = Deno.env.get("FEDAPAY_ENV") || "sandbox";
const FEDAPAY_BASE = FEDAPAY_ENV === "live"
  ? "https://api.fedapay.com/v1"
  : "https://sandbox-api.fedapay.com/v1";
const FEDAPAY_SECRET_KEY = Deno.env.get("FEDAPAY_SECRET_KEY")!;

const supabaseAdmin = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const { order_id, return_url } = await req.json();
    if (!order_id) throw new Error("order_id manquant");

    // 1. Récupère la commande "pending" (avec le montant réel — jamais
    //    faire confiance à un montant envoyé par le navigateur).
    const { data: order, error: orderErr } = await supabaseAdmin
      .from("orders")
      .select("id, amount, buyer_name, buyer_phone, payment_status, events(title)")
      .eq("id", order_id)
      .single();

    if (orderErr || !order) throw new Error("Commande introuvable");
    if (order.payment_status !== "pending") throw new Error("Cette commande n'est plus en attente de paiement");

    // 2. Crée la transaction chez FedaPay
    const createRes = await fetch(`${FEDAPAY_BASE}/transactions`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${FEDAPAY_SECRET_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        description: `Ticket — ${order.events?.title || "Fest&Chill"} (commande ${order.id})`,
        amount: order.amount,
        currency: { iso: "XOF" },
        callback_url: return_url || "https://festchill.example.com/festchill-buy-ticket.html",
        customer: {
          firstname: order.buyer_name || "Client",
          lastname: "Fest&Chill",
          phone_number: { number: order.buyer_phone, country: "bj" },
        },
      }),
    });
    const createData = await createRes.json();
    if (!createRes.ok) throw new Error(createData?.message || "Échec de création de la transaction FedaPay");
    const transactionId = createData["v1/transaction"]?.id || createData.id;

    // 3. Génère le lien de paiement (token) pour cette transaction
    const tokenRes = await fetch(`${FEDAPAY_BASE}/transactions/${transactionId}/token`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${FEDAPAY_SECRET_KEY}` },
    });
    const tokenData = await tokenRes.json();
    if (!tokenRes.ok) throw new Error(tokenData?.message || "Échec de génération du lien de paiement");

    // 4. Mémorise l'ID de transaction FedaPay sur la commande pour que
    //    le webhook sache quelle commande confirmer plus tard.
    await supabaseAdmin.from("orders").update({ fedapay_transaction_id: String(transactionId) }).eq("id", order_id);

    return new Response(
      JSON.stringify({ payment_url: tokenData.url, token: tokenData.token }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
